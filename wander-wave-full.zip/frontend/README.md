# Wander Wave Frontend
Create a `.env` file from `.env.sample` to set the API URL.

## Run
```bash
npm install
npm run dev
```